import experiment1 as exp1
import experiment2 as exp2
import numpy as np

if __name__ == '__main__':
    np.random.seed(902764819)
    exp1.main()
    exp2.main()